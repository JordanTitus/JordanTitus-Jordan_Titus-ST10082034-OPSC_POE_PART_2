package com.example.opscwork
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TimeEntriesAdapter(private val timeEntries: List<TimeEntry>) :
    RecyclerView.Adapter<TimeEntriesAdapter.TimeEntryViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TimeEntryViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_time_entry, parent, false)
        return TimeEntryViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: TimeEntryViewHolder, position: Int) {
        val timeEntry = timeEntries[position]
        holder.bind(timeEntry)
    }

    override fun getItemCount(): Int {
        return timeEntries.size
    }

    inner class TimeEntryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val textViewDate: TextView = itemView.findViewById(R.id.textViewDate)
        private val textViewTime: TextView = itemView.findViewById(R.id.textViewTime)
        private val textViewDescription: TextView = itemView.findViewById(R.id.textViewDescription)
        private val textViewCategory: TextView = itemView.findViewById(R.id.textViewCategory)


        fun bind(timeEntry: TimeEntry) {
            textViewDate.text = timeEntry.date
            val timeRange = "${timeEntry.startTime} - ${timeEntry.endTime}"
            textViewTime.text = timeRange
            textViewDescription.text = timeEntry.description
            textViewCategory.text = timeEntry.category
        }
    }
}

