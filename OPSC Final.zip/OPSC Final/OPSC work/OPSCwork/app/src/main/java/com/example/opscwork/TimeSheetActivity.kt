package com.example.opscwork

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList
import com.example.opscwork.Globals

class TimeSheetActivity : AppCompatActivity() {

    private lateinit var editTextDate: EditText
    private lateinit var editTextStartTime: EditText
    private lateinit var editTextEndTime: EditText
    private lateinit var editTextDescription: EditText
    private lateinit var editTextCategory: EditText
    private lateinit var buttonAddPhoto: Button
    private lateinit var imageViewPhoto: ImageView
    private lateinit var buttonSave: Button
    private lateinit var recyclerViewEntries: RecyclerView

    val globals = Globals()
    val timeEntries = globals.timeEntries
    private lateinit var timeEntriesAdapter: TimeEntriesAdapter

    companion object {
        private const val CAMERA_PERMISSION_REQUEST_CODE = 100
        private const val CAMERA_CAPTURE_REQUEST_CODE = 200
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.timesheet_activity)

        editTextDate = findViewById(R.id.editTextDate)
        editTextStartTime = findViewById(R.id.editTextStartTime)
        editTextEndTime = findViewById(R.id.editTextEndTime)
        editTextDescription = findViewById(R.id.editTextDescription)
        editTextCategory = findViewById(R.id.editTextCategory)
        buttonAddPhoto = findViewById(R.id.buttonAddPhoto)
        imageViewPhoto = findViewById(R.id.imageViewPhoto)
        buttonSave = findViewById(R.id.buttonSave)
        recyclerViewEntries = findViewById(R.id.recyclerViewEntries)

        timeEntriesAdapter = TimeEntriesAdapter(timeEntries)
        recyclerViewEntries.layoutManager = LinearLayoutManager(this)
        recyclerViewEntries.adapter = timeEntriesAdapter

        buttonAddPhoto.setOnClickListener {
            checkCameraPermission()
        }

        buttonSave.setOnClickListener {
            saveTimeEntry()
        }

        val toDailyGoals: Button = findViewById(R.id.btn_toDailyGoals)
        toDailyGoals.setOnClickListener {
            val intent = Intent(this, MainActivity5::class.java)
            startActivity(intent)
        }
    }

    private fun checkCameraPermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            openCamera()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.CAMERA),
                CAMERA_PERMISSION_REQUEST_CODE
            )
        }
    }

    private fun openCamera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(intent, CAMERA_CAPTURE_REQUEST_CODE)
    }

    private fun saveTimeEntry() {
        val date = editTextDate.text.toString()
        val startTime = editTextStartTime.text.toString()
        val endTime = editTextEndTime.text.toString()
        val description = editTextDescription.text.toString()
        val category = editTextCategory.text.toString()
        val photoPath = getImagePathFromImageView()

        val timeEntry = TimeEntry(date, startTime, endTime, description, category, photoPath)

        timeEntries.add(timeEntry)
        timeEntriesAdapter.notifyDataSetChanged()

        clearFields()
    }

    private fun clearFields() {
        editTextDate.text.clear()
        editTextStartTime.text.clear()
        editTextEndTime.text.clear()
        editTextDescription.text.clear()
        editTextCategory.text.clear()
        imageViewPhoto.setImageDrawable(null)
        imageViewPhoto.visibility = View.GONE
    }

    private fun getImagePathFromImageView(): String? {
        val drawable = imageViewPhoto.drawable ?: return null
        val bitmap = (drawable as BitmapDrawable).bitmap
        val byteArrayOutputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream)
        val byteArray = byteArrayOutputStream.toByteArray()
        val file = File(filesDir, "time_entry_${System.currentTimeMillis()}.png")
        val fileOutputStream = FileOutputStream(file)
        fileOutputStream.write(byteArray)
        fileOutputStream.flush()
        fileOutputStream.close()
        return file.absolutePath
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_REQUEST_CODE && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            openCamera()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CAMERA_CAPTURE_REQUEST_CODE && resultCode == RESULT_OK) {
            val imageBitmap = data?.extras?.get("data") as Bitmap
            imageViewPhoto.setImageBitmap(imageBitmap)
            imageViewPhoto.visibility = View.VISIBLE
        }
    }
}