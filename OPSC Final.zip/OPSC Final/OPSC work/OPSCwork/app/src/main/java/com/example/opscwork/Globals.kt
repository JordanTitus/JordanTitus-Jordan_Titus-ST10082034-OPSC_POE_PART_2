package com.example.opscwork

class Globals {
    var timeEntries: MutableList<TimeEntry> = mutableListOf()

}