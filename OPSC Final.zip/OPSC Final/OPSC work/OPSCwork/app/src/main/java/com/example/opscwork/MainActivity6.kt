package com.example.opscwork

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import com.squareup.picasso.Picasso

class MainActivity6 : AppCompatActivity() {

    private lateinit var listView: ListView // ListView to display the timesheet entries
    private lateinit var imageView: ImageView // ImageView to display the associated photo

    // List of timesheet entries with their titles and photo URLs
    private val timesheetEntries = listOf(
        TimesheetEntry("Entry 1", null),
        TimesheetEntry("Entry 2", "https://example.com/photo1.jpg"),
        TimesheetEntry("Entry 3", "https://example.com/photo2.jpg")
        // Add more entries as needed
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main6)

        // Initialize ListView and ImageView
        listView = findViewById(R.id.listViewEntries)
        imageView = findViewById(R.id.imageViewPhoto)

        // Create an array of entry titles for the ListView
        val entryTitles = timesheetEntries.map { it.title }

        // Create an ArrayAdapter to populate the ListView with the entry titles
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, entryTitles)
        listView.adapter = adapter

        // Set a click listener for the ListView items
        listView.onItemClickListener =
            AdapterView.OnItemClickListener { _, _, position, _ ->
                val entry = timesheetEntries[position] // Get the selected timesheet entry
                if (entry.photoUrl != null) { // If a photo URL is available
                    imageView.visibility = View.VISIBLE // Show the ImageView
                    // Load the photo into the ImageView using Picasso library
                    Picasso.get().load(entry.photoUrl).into(imageView)
                } else {
                    imageView.visibility = View.GONE // Hide the ImageView if no photo URL
                }
            }

        // Set a click listener for the "Load Entries" button
        val btnLoadEntries: Button = findViewById(R.id.btnLoadEntries)
        btnLoadEntries.setOnClickListener {
            // Implement loading of entries here (to be added)
            adapter.notifyDataSetChanged() // Refresh the ListView if needed
            imageView.visibility = View.GONE // Hide the ImageView
        }

        // Set a click listener for the "Load Photos" button
        val btnLoadPhotos: Button = findViewById(R.id.btnLoadPhotos)
        btnLoadPhotos.setOnClickListener {
            // Implement loading of photos here (to be added)
            imageView.visibility = View.GONE // Hide the ImageView
        }

        val toTimePeriod: Button = findViewById(R.id.btn_toTimePeriod)
        toTimePeriod.setOnClickListener {
            val intent = Intent(this, Point7::class.java)
            startActivity(intent)
        }
    }
}

