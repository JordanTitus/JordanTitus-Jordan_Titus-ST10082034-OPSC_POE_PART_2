package com.example.opscwork

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.widget.Button
import android.widget.EditText


class MainActivity5 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main5)
        val minimumGoalEditText = findViewById<EditText>(R.id.minimumGoalEditText)
        val maximumGoalEditText = findViewById<EditText>(R.id.maximumGoalEditText)
        val saveButton = findViewById<Button>(R.id.saveButton)

        // Save button click listener
        saveButton.setOnClickListener()
        {
            val minimumGoalValue = minimumGoalEditText.text.toString().toInt()
            val maximumGoalValue = maximumGoalEditText.text.toString().toInt()
            setDailyGoals(minimumGoalValue, maximumGoalValue)
        }

        val toViewPhoto: Button = findViewById(R.id.btn_toViewPhoto)
        toViewPhoto.setOnClickListener {
            val intent = Intent(this, MainActivity6::class.java)
            startActivity(intent)
        }

        val retrievedMinimumGoal = getMinimumDailyGoal()
        val retrievedMaximumGoal = getMaximumDailyGoal()
    }
    // Add the following code inside your activity
    //Point 5's code. This code must be in the MainActivity or it won't work. SharePreferences is weird like that.
    // Function to set the minimum and maximum daily goals
    //Note minimumGoal and maximumGoal are user defined variables
    private fun setDailyGoals(minimumGoal: Int, maximumGoal: Int)
    {
        // Save the goals in SharedPreferences (Persistent Storage)
        val sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putInt("MinimumGoal", minimumGoal)
        editor.putInt("MaximumGoal", maximumGoal)
        editor.apply()
    }

    // Function to get the minimum daily goal
    private fun getMinimumDailyGoal(): Int
    {
        val sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        return sharedPreferences.getInt("MinimumGoal", 0) // Default value is 0 if not set
    }

    // Function to get the maximum daily goal
    private fun getMaximumDailyGoal(): Int
    {
        val sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        return sharedPreferences.getInt("MaximumGoal", 0) // Default value is 0 if not set
    }
}
//Websites used for sharedPreferences
//https://developer.android.com/training/data-storage/shared-preferences
//https://www.geeksforgeeks.org/shared-preferences-in-android-with-examples/