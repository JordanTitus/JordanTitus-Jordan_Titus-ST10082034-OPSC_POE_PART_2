package com.example.opscwork

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.*
import com.example.opscwork.TimeEntry
import com.example.opscwork.TimeSheetActivity

class Point7 : AppCompatActivity() {
    val globals = Globals()
    val timeEntries = globals.timeEntries

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_point7)

        val btnSelectDate = findViewById<Button>(R.id.btnSelectDate)
        val etStartDate = findViewById<EditText>(R.id.etStartDate)
        val etEndDate = findViewById<EditText>(R.id.etEndDate)
        val tvTotalHoursByCategory = findViewById<TextView>(R.id.tvTotalHoursByCategory)
        val stringBuilder = StringBuilder()
        val timeEntries: MutableList<TimeEntry> = mutableListOf()
        outsideFunction(timeEntries)
        // SelectDate button click listener
        btnSelectDate.setOnClickListener()
        {
            val startDate = etStartDate.text.toString().toLong()
            val endDate = etEndDate.text.toString().toLong()
            val totalHoursByCategory = calculateTotalHoursByCategory(startDate, endDate)
            //Iterate over the total hours by category and display the results
            for ((category, totalHours) in totalHoursByCategory) {
                //Uses StringBuilder to add data to text view
                val categoryHoursText = "Category: $category, Total Hours: $totalHours"
                stringBuilder.append(categoryHoursText).append("\n")
            }

            val toCategories: Button = findViewById(R.id.btn_toCategories)
            toCategories.setOnClickListener {
                val intent = Intent(this, Categories::class.java)
                startActivity(intent)
            }
            //Setting TextView equal to stringBuilder
            tvTotalHoursByCategory.text = stringBuilder.toString()
        }
    }
    private fun outsideFunction(entries: List<TimeEntry>) {
        // Access and use the timeEntries list here
        val allEntries: List<TimeEntry> = entries

        // Your code to work with allEntries...
    }
    private fun calculateTotalHoursByCategory(startDate: Long, endDate: Long): Map<String, Float> {
        val entries = filteredEntries(startDate, endDate) // Retrieve timesheet entries within the selected period

        //A mutable map called totalHoursByCategory is created to store the total hours spent on each category.
        // The key of the map represents the category, and the value represents the total hours for that category.
        val totalHoursByCategory = mutableMapOf<String, Float>()

        for (entry in entries) {
            val category = entry.category
            // Custom method to calculate the hours between start and end times
            //Look inside the TimesheetEntry Class
            val hours = entry.calculateHours()

            //Check if the map exists
            //If it exists, add the hours to the value, otherwise create a new category with the hours.
            if (totalHoursByCategory.containsKey(category)) {
                totalHoursByCategory[category] = totalHoursByCategory[category]!! + hours
            } else {
                totalHoursByCategory[category] = hours
            }
        }

        return totalHoursByCategory
    }

    // Function to get the timesheet entries within a selected period
    //TimesheetEntry is just the list where the Timesheet Entries are stored.
    private fun filteredEntries(startDate: Long, endDate: Long): List<TimeEntry> {
        val startDateTime = Date(startDate)
        val endDateTime = Date(endDate)
        //Just Replace this with code to get the Timesheet Entries
        //This was to see for errors0
        // Actual list of TimesheetEntries
        //This data is just an example to stop errors
        //mutableListOf() needs to be timeEntries from the TimeSheetActivity Class
        val allEntries: List<TimeEntry> = timeEntries
        val filteredEntries = mutableListOf<TimeEntry>()

        // Iterate through all timesheet entries and filter based on the selected period
        for (entry in allEntries) {
            val entryDate = parseDateTime(entry.date)
            if (entryDate in startDateTime..endDateTime) {
                filteredEntries.add(entry)
            }
        }

        return filteredEntries
    }
    private fun parseDateTime(time: String): Date {
        val dateFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
        return dateFormat.parse(time)
    }
}
//Website used to create mutableMapOf
//https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/mutable-map-of.html
//https://www.baeldung.com/kotlin/concatenate-strings
//https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.text/-string-builder/