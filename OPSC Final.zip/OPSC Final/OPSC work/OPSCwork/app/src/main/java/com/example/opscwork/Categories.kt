package com.example.opscwork

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView


class Categories : AppCompatActivity() {

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navigationView: NavigationView
    private lateinit var drawerToggle: ActionBarDrawerToggle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_categories)

        val listView: ListView = findViewById(R.id.listView)
        val categoryName: EditText = findViewById(R.id.categoryName)



        val items = mutableListOf<String>() // Create a mutable list to store the items

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, items)
        listView.adapter = adapter

// Add an item to the list when a button is clicked
        val addButton: Button = findViewById(R.id.btn_addCategory)
        addButton.setOnClickListener {
            val newItem = categoryName.text.toString() // Get the text from the EditText
            if (newItem.isNotEmpty()) {
                items.add(newItem) // Add the new item to the list
                adapter.notifyDataSetChanged() // Notify the adapter that the data has changed
                categoryName.text.clear() // Clear the EditText

            }

        }

        val toTimsheet: Button = findViewById(R.id.btn_toTimesheet)
        toTimsheet.setOnClickListener {
            val intent = Intent(this, TimeSheetActivity::class.java)
            startActivity(intent)
        }
    }
}